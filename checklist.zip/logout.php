<?php require('includes/config.php');


$user->logout(); 


header('Location: index.php');
exit;
?>